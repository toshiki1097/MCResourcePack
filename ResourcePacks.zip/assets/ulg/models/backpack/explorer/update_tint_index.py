import os
import json

def main():
    # Get user input
    while (True):
        group_name = input("Enter the group name: ").strip()
        tint_index = int(input("Enter the tint index (integer): ").strip())
        
        currentDir = os.path.dirname(__file__)+"/"
        
        # Get all .json files in the current directory
        json_files = [f for f in os.listdir(currentDir) if f.endswith('.json')]
        
        for file_name in json_files:
            print("file -> "+file_name)
            try:
                # Load JSON content
                with open(currentDir+file_name, 'r') as file:
                    data = json.load(file)
                    
                    # Check if "groups" exist in the JSON
                    if "groups" in data and "elements" in data:
                        for group in data["groups"]:
                            print("found group -> "+group.get("name"))
                            if group.get("name") == group_name:
                                # Modify the tint index for children of the matching group
                                for child_index in group.get("children", []):
                                    if 0 <= child_index < len(data["elements"]):
                                        element = data["elements"][child_index]
                                        if "faces" in element:
                                            for face in element["faces"].values():
                                                face["tintindex"] = tint_index
                                
                                print(f"Updated group '{group_name}' in file '{file_name}'")
                    # Save the modified JSON
                    with open(currentDir+file_name, 'w') as file:
                        json.dump(data, file, indent=4)
            except Exception as e:
                print(f"Error processing file '{file_name}': {e}")
        input()

if __name__ == "__main__":
    main()